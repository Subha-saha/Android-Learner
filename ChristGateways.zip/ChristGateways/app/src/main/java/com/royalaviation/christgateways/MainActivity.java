package com.royalaviation.christgateways;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText uName,uEmail,uCollege,uPhone;
    private Button btnSubmit;
    private ProgressDialog pd;

    private String bName,bEmail,bCollege,bPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        uName = findViewById(R.id.etName);
        uEmail = findViewById(R.id.etEmail);
        uCollege = findViewById(R.id.etCollege);
        uPhone = findViewById(R.id.etPhone);
        btnSubmit = findViewById(R.id.btnSubmit);
        pd = new ProgressDialog(this);
        Intent i = getIntent();
        bName = i.getStringExtra("name");
        bEmail = i.getStringExtra("email");
        bCollege = i.getStringExtra("college");
        bPhone = i.getStringExtra("phone");

        uName.setText(bName);
        uEmail.setText(bEmail);
        uCollege.setText(bCollege);
        uPhone.setText(bPhone);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validateData();
            }
        });

    }

    private void validateData() {
        String Name = uName.getText().toString();
        String Email = uEmail.getText().toString();
        String College = uCollege.getText().toString();
        String Phone = uPhone.getText().toString();

        if(Name.isEmpty()){
            uName.setError("Please enter your name");
            uName.requestFocus();
            return;
        }
        if(Email.isEmpty()){
            uEmail.setError("Please enter your email");
            uEmail.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(Email).matches())
        {
            uEmail.setError("Please Provide a Valid Email Id");
            uEmail.requestFocus();
            return;
        }
        if(College.isEmpty()){
            uCollege.setError("Please enter college name");
            uCollege.requestFocus();
            return;
        }
        if(Phone.isEmpty()){
            uPhone.setError("Please enter your mobile number");
            uPhone.requestFocus();
            return;
        }
        if(Phone.length()!=10)
        {
            uPhone.setError("Phone no should be only of 10 digits");
            uPhone.requestFocus();
            return;
        }
        pd.setTitle("Registration");
        pd.setMessage("Please wait,while we are checking the validating credentials");
        pd.setCanceledOnTouchOutside(false);
        pd.show();
        Intent intent = new Intent(getApplicationContext(), VerifyActivity.class);
        intent.putExtra("name", uName.getText().toString());
        intent.putExtra("email",uEmail.getText().toString());
        intent.putExtra("college",uCollege.getText().toString());
        intent.putExtra("phone",uPhone.getText().toString());
        startActivity(intent);

    }
}