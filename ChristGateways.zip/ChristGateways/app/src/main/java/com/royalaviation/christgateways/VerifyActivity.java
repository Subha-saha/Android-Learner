package com.royalaviation.christgateways;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class VerifyActivity extends AppCompatActivity {

    private TextView tvName,tvEmail,tvCollege,tvPhone;
    private Button btnCnf,btnEdit;
    private String Name,Email,College,Phone;
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify);
        getSupportActionBar().hide();
        Intent intent =  getIntent();
        builder = new AlertDialog.Builder(this);
        Name = intent.getStringExtra("name");
        Email = intent.getStringExtra("email");
        College = intent.getStringExtra("college");
        Phone = intent.getStringExtra("phone");
        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);
        tvCollege = findViewById(R.id.tvCollege);
        tvPhone = findViewById(R.id.tvPhone);

        btnCnf = findViewById(R.id.btnCnf);
        btnEdit = findViewById(R.id.btnGo);

        tvName.setText(Name);
        tvEmail.setText(Email);
        tvCollege.setText(College);
        tvPhone.setText(Phone);

        btnCnf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                builder.setTitle("Confirm");
                builder.setMessage("Are you sure?").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(), "You have successfully registered for Gateways", Toast.LENGTH_SHORT).show();
                        Intent intent1 = new Intent(getApplicationContext(),ThanksActivity.class);
                        startActivity(intent1);
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(getApplicationContext(),MainActivity.class);
                intent1.putExtra("name",Name);
                intent1.putExtra("email",Email);
                intent1.putExtra("college",College);
                intent1.putExtra("phone",Phone);
                startActivity(intent1);
            }
        });


    }


}